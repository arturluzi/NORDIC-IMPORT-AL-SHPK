document.querySelectorAll('.product-btn').forEach(button => {
  button.addEventListener('click', () => {
    const productName = button.parentElement.querySelector('h3').textContent;
    alert(`Ju keni zgjedhur: ${productName}`);
  });
});

window.addEventListener('scroll', () => {
  const header = document.querySelector('header');
  header.style.backgroundColor = window.scrollY > 50 ? '#003d82' : '#0056b3';
});